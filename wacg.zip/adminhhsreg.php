<?php 
include("db.php");
date_default_timezone_set('Asia/Kolkata'); 
$date=date('Y-m-d H:i:s');
if(isset($_SESSION['admin_id']))
{
	$login = $_SESSION['login'];
	if(isset($_POST['register']))
	{	
$hhd_check = mysqli_query($link, "SELECT * from `householdreg` where mobile='".$_POST['mobile']."'") or die(mysqli_error($link));
	$count = mysqli_num_rows($hhd_check);
	$check = mysqli_fetch_assoc($hhd_check); 
		if($count==0)
			{


		$insert_sql="INSERT INTO `householdreg`(`category`, `name`, `email`, `mobile`, `location`, `address`, `password`, `dateofreg`) VALUES ('".$_POST['category']."','".$_POST['name']."','".$_POST['email']."','".$_POST['mobile']."','".$_POST['location']."','".$_POST['address']."','".$_POST['password']."','".$date."')";
		
					
		$result=mysqli_query($link,$insert_sql);
		 $id=mysqli_insert_id($link); 
		$insert_userloginsql="INSERT INTO `user_login`(`userid`, `password`, `role`) VALUES('".$_POST['mobile']."','".$_POST['password']."','household')";		
			
		$userlogin_result=mysqli_query($link,$insert_userloginsql);
  
       
        
	
		if($result||$userlogin_result)
		{
echo "<script>alert('Details Uploaded Successfully');window.location = 'adminhhsreg.php';</script>";
		}
	
		
	}
		else
		{
	echo "<script language='javascript'>alert('A Household Service Already Registered');window.location = 'adminhhsreg.php';</script>";
			
		}
		
	}

?>
<! DOC TYPE HTML>
<html>
<head>
<title>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="images/bg.jpg">
<form action="" method="POST">

<div class="form-group">
  <div class="container">
 <div class="container-fluid">
    <div class="row">
	  <div class="col-md-8">
         <h1 style="color:#2FA4C7;font-weight:bold;">CUSTOM GUIDENCE</h1>
      </div>
	  	 
    </div>
	</div>
<div class="container-fluid">
	  <div class="row">
	  <div class="col-md-12">
<nav class="navbar navbar-inverse">
 
    <ul class="nav navbar-nav">
      <li class="active"><a href="adminhome.php">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Hospital Services<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="adminhospreg.php">Register</a></li>
          <li><a href="adminviewupdatehosp.php">View/Update</a></li>
        </ul>
      </li>
	      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Household Services<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="adminhhsreg.php">Register</a></li>
          <li><a href="adminviewupdatehhs.php">View/Update</a></li>
        </ul>
      </li>

	   <li><a href="adminchangepassword.php">Change Password</a></li>
	   <li><a href="adminlogout.php">Logout</a></li>
    </ul>
</nav>
</div>
</div>
</div>
<h1 class="text-center">Household Services Registration</h1>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-th-list"></i></span>
   <select class="form-control" id="category" name="category">
	<option value="">Category</option>
<option value="Cleaning">Cleaning</option>
<option value="TV and Electronics">TV and Electronics</option>
<option value="Assembly">Assembly</option>
<option value="General Handyman">General Handyman</option>
<option value="Plumbing">Plumbing</option>
<option value="Electrical">Electrical</option>
<option value="Painting">Painting</option>
<option value="Moving">Moving</option>
<option value="Smart Home">Smart Home</option>
<option value="Window Treatments">Window Treatments</option>
	</select>
    </div>
	</div>
	</div>
	</div>
<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input id="name" type="text" class="form-control" name="name" placeholder="Enter Your Name" required>
    </div>
	</div>
	</div>
	</div>
<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
      <input id="email" type="email" class="form-control" name="email" placeholder="Enter Your Email" required>
    </div>
	</div>
	</div>
	</div>
	<br>
		<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
      <input id="mobile" type="text" class="form-control" name="mobile" placeholder="Enter Your Mobile Number" required pattern="^[6789]\d{9}$">
    </div>
	</div>
	</div>
	</div>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
     <select class="form-control" id="location" name="location">
	<option>Location</option>
	<option value="Bhimavaram">Bhimavaram</option>
	<option value="Tanuku">Tanuku</option>
	<option value="Rajahmundry">Rajahmundry</option>
	
	</select>
    </div>
	</div>
	</div>
	</div>
	<br>
<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-list-alt"></i></span>
     <textarea class="form-control" placeholder="Address" name="address"></textarea> 
    </div>
</div>
	</div>
	</div>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
</div>
	</div>
	</div>
	<br>
	<center>
	
  <div class="container">
	<div class="row">
	 <div class="col-md-12">
	<div class="input-group">
     <button type="submit" class="btn btn-default" name="register"><i class="glyphicon glyphicon-upload"></i>Register</button>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
  </form>
	</body>
	</html>
		<?php
}
else
{
echo "<script language='javascript'>window.location = 'adminlogin.php';</script>";exit();
}
?>