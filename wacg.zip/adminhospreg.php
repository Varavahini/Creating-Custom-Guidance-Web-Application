<?php 
include("db.php");
date_default_timezone_set('Asia/Kolkata'); 
$date=date('Y-m-d H:i:s');
if(isset($_SESSION['admin_id']))
{
	$login = $_SESSION['login'];
	if(isset($_POST['register']))
	{	
$hd_check = mysqli_query($link, "SELECT * from `hospreg` where mobile='".$_POST['mobile']."'") or die(mysqli_error($link));
	$count = mysqli_num_rows($hd_check);
	$check = mysqli_fetch_assoc($hd_check); 
		if($count==0)
			{


		
				$insert_sql="INSERT INTO `hospreg`(`specialization`,`hospitalname`, `doctorname`, `qualification`, `email`, `mobile`, `location`, `address`, `services`, `password`, `dateofreg`) VALUES ('".$_POST['specialization']."','".$_POST['hospitalname']."','".$_POST['doctorname']."','".$_POST['qualification']."','".$_POST['email']."','".$_POST['mobile']."','".$_POST['location']."','".$_POST['address']."','".$_POST['services']."','".$_POST['password']."','".$date."')";
		
			
		$result=mysqli_query($link,$insert_sql);
		 $id=mysqli_insert_id($link); 
		$insert_userloginsql="INSERT INTO `user_login`(`userid`, `password`, `role`) VALUES('".$_POST['email']."','".$_POST['password']."','hospital')";	
			
		$userlogin_result=mysqli_query($link,$insert_userloginsql);
        //echo $insert_userloginsql;
       
        
	
		if($result||$userlogin_result)
		{
echo "<script>alert('Details Uploaded Successfully');window.location = 'adminhospreg.php';</script>";
		}
	
		
	}
		else
		{
	echo "<script language='javascript'>alert('A Hospital Already Registered');window.location = 'adminhospreg.php';</script>";
			
		}
		
	}

?>
<! DOC TYPE HTML>
<html>
<head>
<title>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="images/bg.jpg">
<form action="" method="POST">

<div class="form-group">
  <div class="container">
 <div class="container-fluid">
    <div class="row">
	  <div class="col-md-8">
         <h1 style="color:#2FA4C7;font-weight:bold;">CUSTOM GUIDENCE</h1>
      </div>
	  	 
    </div>
	</div>
<div class="container-fluid">
	  <div class="row">
	  <div class="col-md-12">
<nav class="navbar navbar-inverse">
 
    <ul class="nav navbar-nav">
      <li class="active"><a href="adminhome.php">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Hospital Services<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="adminhospreg.php">Register</a></li>
          <li><a href="adminviewupdatehosp.php">View/Update</a></li>
        </ul>
      </li>
	      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Household Services<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="adminhhsreg.php">Register</a></li>
          <li><a href="adminviewupdatehhs.php">View/Update</a></li>
        </ul>
      </li>

	   <li><a href="adminchangepassword.php">Change Password</a></li>
	   <li><a href="adminlogout.php">Logout</a></li>
    </ul>
</nav>
</div>
</div>
</div>
<h1 class="text-center">Hospital Services Registration</h1>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-th-list"></i></span>
   <select class="form-control" id="specialization" name="specialization">
	<option value="">Specialization</option>
<option value="Accident and emergency medicine">Accident and emergency medicine</option>
<option value="Allergology">Allergology</option>
<option value="Anaesthetics">Anaesthetics</option>
<option value="Cardiology">Cardiology</option>
<option value="Child psychiatry">Child psychiatry</option>
<option value="Clinical biology">Clinical biology</option>
<option value="Clinical chemistry">Clinical chemistry</option>
<option value="Clinical microbiology">Clinical microbiology</option>
<option value="Clinical neurophysiology">Clinical neurophysiology</option>
<option value="Craniofacial surgery">Craniofacial surgery</option>
<option value="Dermatology">Dermatology</option>
<option value="Endocrinology">Endocrinology</option>
<option value="Family and General Medicine">Family and General Medicine</option>
<option value="Gastroenterologic surgery">Gastroenterologic surgery</option>
<option value="Gastroenterology">Gastroenterology</option>
<option value="General Practice">General Practice</option>
<option value="General surgery">General surgery</option>
<option value="Geriatrics">Geriatrics</option>
<option value="Hematology">Hematology</option>
<option value="Immunology">Immunology</option>
<option value="Infectious diseases">Infectious diseases</option>
<option value="Internal medicine">Internal medicine</option>
<option value="Laboratory medicine">Laboratory medicine</option>
<option value="Nephrology">Nephrology</option>
<option value="Neuropsychiatry">Neuropsychiatry</option>
<option value="Neurology">Neurology</option>
<option value="Neurosurgery">Neurosurgery</option>
<option value="Nuclear medicine">Nuclear medicine</option>
<option value="Obstetrics and gynaecology">Obstetrics and gynaecology</option>
<option value="Occupational medicine">Occupational medicine</option>
<option value="Oncology">Oncology</option>
<option value="Ophthalmology">Ophthalmology</option>
<option value="Oral and maxillofacial surgery">Oral and maxillofacial surgery</option>
<option value="Orthopaedics">Orthopaedics</option>
<option value="Otorhinolaryngology">Otorhinolaryngology</option>
<option value="Paediatric surgery">Paediatric surgery</option>
<option value="Paediatrics">Paediatrics</option>
<option value="Pathology">Pathology</option>
<option value="Pharmacology">Pharmacology</option>
<option value="Physical medicine and rehabilitation">Physical medicine and rehabilitation</option>
<option value="Plastic surgery">Plastic surgery</option>
<option value="Podiatric surgery">Podiatric surgery</option>
<option value="Preventive medicine">Preventive medicine</option>
<option value="Psychiatry">Psychiatry</option>
<option value="Public health">Public health</option>
<option value="Radiation Oncology">Radiation Oncology</option>
<option value="Radiology">Radiology</option>
<option value="Respiratory medicine">Respiratory medicine</option>
<option value="Rheumatology">Rheumatology</option>
<option value="Stomatology">Stomatology</option>
<option value="Thoracic surgery">Thoracic surgery</option>
<option value="Tropical medicine">Tropical medicine</option>
<option value="Urology">Urology</option>
<option value="Vascular surgery">Vascular surgery</option>
<option value="Venereology">Venereology</option>
	</select>
    </div>
	</div>
	</div>
	</div>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input id="name" type="text" class="form-control" name="hospitalname" placeholder="Enter Your Hospital Name" required>
    </div>
	</div>
	</div>
	</div>
<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input id="name" type="text" class="form-control" name="doctorname" placeholder="Enter Your Doctor Name" required>
    </div>
	</div>
	</div>
	</div>
<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
      <input id="qualification" type="text" class="form-control" name="qualification" placeholder="Enter Qualification" required>
    </div>
	</div>
	</div>
	</div>
<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
      <input id="email" type="email" class="form-control" name="email" placeholder="Enter Your Email" required>
    </div>
	</div>
	</div>
	</div>
	<br>
		<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
      <input id="mobile" type="text" class="form-control" name="mobile" placeholder="Enter Your Mobile Number" required pattern="^[6789]\d{9}$">
    </div>
	</div>
	</div>
	</div>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
     <select class="form-control" id="location" name="location">
	<option>Location</option>
	<option value="Bhimavaram">Bhimavaram</option>
	<option value="Tanuku">Tanuku</option>
	<option value="Rajahmundry">Rajahmundry</option>
	
	</select>
    </div>
	</div>
	</div>
	</div>
	<br>
<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-list-alt"></i></span>
     <textarea class="form-control" placeholder="Address" name="address"></textarea> 
    </div>
</div>
	</div>
	</div>
	<br>
<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-list-alt"></i></span>
     <textarea class="form-control" placeholder="Services" name="services"></textarea> 
    </div>
</div>
	</div>
	</div>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
</div>
	</div>
	</div>
	<br>
	<center>
	
  <div class="container">
	<div class="row">
	 <div class="col-md-12">
	<div class="input-group">
     <button type="submit" class="btn btn-default" name="register"><i class="glyphicon glyphicon-upload"></i>Register</button>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
  </form>
	</body>
	</html>
	<?php
}
else
{
echo "<script language='javascript'>window.location = 'adminlogin.php';</script>";exit();
}
?>