<?php
error_reporting(0);
include_once "db.php";

if(isset($_POST['login']))
{
	$login_check = mysqli_query($link, "SELECT * from `user_login` where userid='".$_POST['uname']."'  and password='".$_POST['pwd']."'") or die(mysqli_error($link));
	$count = mysqli_num_rows($login_check);
	$check = mysqli_fetch_assoc($login_check); 
		if($count==1)
			{
				$_SESSION['login'] = $check['userid'];
				if($check['role']=='admin')
				{
				$_SESSION['admin_id'] = $check['id'];
				$_SESSION['admin_name'] = $check['userid'];
				echo "<script language='javascript'>alert('Login Successfully');window.location = 'adminhome.php';</script>";
				}
			
					
			}
		else
			{
				?>
         <script>
			 alert("Wrong Credentials.");
			window.location = 'adminlogin.php';
         </script>
         <?php
			}
}
?>
<! DOC TYPE HTML>
<html>
<head>
<title>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="images/bg.jpg">
<form action="" method="POST">

<div class="form-group">
  <div class="container">
 <div class="container-fluid">
    <div class="row">
	  <div class="col-md-8">
        <h1 style="color:#2FA4C7;font-weight:bold;">CUSTOM GUIDENCE</h1>
      </div>
	 
    </div>
	</div>

<h1 class="text-center">Login</h1>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
      <input id="uname" type="text" class="form-control" name="uname" placeholder="Enter Username">
    </div>
	</div>
	</div>
	</div>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="password" type="password" class="form-control" name="pwd" placeholder="Password">
    </div>
</div>
	</div>
	</div>
	<br>
	<center>
	
  <div class="container">
	<div class="row">
	 <div class="col-md-12">
	<div class="input-group">
     <button type="submit" class="btn btn-default" name="login"><i class="glyphicon glyphicon-upload"></i>Login</button>
	</div>
	</div>
	</div>
	</div>
	</center>
	</div>
  </form>
	</body>
	</html>