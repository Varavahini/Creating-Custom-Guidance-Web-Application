<?php 
include("db.php");
date_default_timezone_set('Asia/Kolkata'); 
$date=date('Y-m-d H:i:s');
if(isset($_SESSION['admin_id']))
{
	$login = $_SESSION['login'];
?>
<! DOC TYPE HTML>
<html>
<head>
<title>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="images/bg.jpg">
<form action="" method="POST">

<div class="form-group">
  <div class="container">
 <div class="container-fluid">
    <div class="row">
	  <div class="col-md-8">
         <h1 style="color:#2FA4C7;font-weight:bold;">CUSTOM GUIDENCE</h1>
      </div>
	  	 
    </div>
	</div>
<div class="container-fluid">
	  <div class="row">
	  <div class="col-md-12">
<nav class="navbar navbar-inverse">
 
    <ul class="nav navbar-nav">
      <li class="active"><a href="adminhome.php">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Hospital Services<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="adminhospreg.php">Register</a></li>
          <li><a href="adminviewupdatehosp.php">View/Update</a></li>
        </ul>
      </li>
	      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Household Services<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="adminhhsreg.php">Register</a></li>
          <li><a href="adminviewupdatehhs.php">View/Update</a></li>
        </ul>
      </li>

	   <li><a href="adminchangepassword.php">Change Password</a></li>
	   <li><a href="adminlogout.php">Logout</a></li>
    </ul>
</nav>
</div>
</div>
</div>
<h1 class="text-center">View & Update Household Services</h1>
  <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
      <input id="mobile" name="mobile" type="text" class="form-control"  placeholder="Enter Mobile Number" required>
    </div><br>
<center>
	<div class="form-group">
  <div class="container-fluid">
	<div class="row">
	 <div class="col-md-12">
	<div class="input-group">
      <button type="submit" class="btn btn-default" name="viewhhs" id="viewhhs"><i class="glyphicon glyphicon-search"></i>View</button>
	</div>
	</div>
	</div>
	</div>
	</div>
	</center>
</div>
</div>

</form>
<?php
if(isset($_POST['viewhhs']))
{
	$sql_get_data="SELECT * FROM `householdreg` WHERE `mobile`='".$_POST['mobile']."'";
		$get_hosp = mysqli_query($link,$sql_get_data) or die(mysqli_error($link));
						$count = mysqli_num_rows($get_hosp);
						if( $count != 0 ){
							while( $row = mysqli_fetch_array($get_hosp) ){
								$id = $row['id'];

$category= $row['category'];
$name= $row['name'];
$email= $row['email'];
$mobile= $row['mobile'];
$location= $row['location'];
$address= $row['address'];
							}
							?>
							<form action="" method="POST">
							<input type="hidden" name="user_id" value="<?php echo $id ; ?>">
							<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-th-list"></i></span>
   <select class="form-control" id="category" name="category">
     <option value="<?php echo $category; ?>"><?php echo $category; ?></option>
	<option value="">Category</option>
<option value="Cleaning">Cleaning</option>
<option value="TV and Electronics">TV and Electronics</option>
<option value="Assembly">Assembly</option>
<option value="General Handyman">General Handyman</option>
<option value="Plumbing">Plumbing</option>
<option value="Electrical">Electrical</option>
<option value="Painting">Painting</option>
<option value="Moving">Moving</option>
<option value="Smart Home">Smart Home</option>
<option value="Window Treatments">Window Treatments</option>
	</select>
    </div>
	</div>
	</div>
	</div>
<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input id="name" type="text" class="form-control" name="name" placeholder="Enter Your Name" required value="<?php echo $name; ?>">
    </div>
	</div>
	</div>
	</div>
<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
      <input id="email" type="email" class="form-control" name="email" placeholder="Enter Your Email" required value="<?php echo $email; ?>">
    </div>
	</div>
	</div>
	</div>
	<br>
		<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
      <input id="mobile" type="text" class="form-control" name="mobile" placeholder="Enter Your Mobile Number" required pattern="^[6789]\d{9}$" value="<?php echo $mobile; ?>">
    </div>
	</div>
	</div>
	</div>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
     <select class="form-control" id="location" name="location">
	 <option value="<?php echo $location; ?>"><?php echo $location; ?></option>
	<option>Location</option>
	<option value="Bhimavaram">Bhimavaram</option>
	<option value="Tanuku">Tanuku</option>
	<option value="Rajahmundry">Rajahmundry</option>
	
	</select>
    </div>
	</div>
	</div>
	</div>
	<br>
<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-list-alt"></i></span>
     <textarea class="form-control" placeholder="Address" name="address"><?php echo $address; ?></textarea> 
    </div>
</div>
	</div>
	</div>
	<br>
	<!--<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
</div>
	</div>
	</div>-->
	<br>
	
	     <center><button type="submit" class="btn btn-default" name="update_details"><i class="glyphicon glyphicon-ok"></i>Update</button></center>
    </div><br>
	</form>
							<?php
						}
						else
						{
							echo "<div style='text-align:center;'>Sorry No Records Found</div>";
						}
}
if(isset($_POST['update_details']))
{
	$hhs_update_qry="UPDATE `householdreg` SET `category`='".$_POST['category']."',`name`='".$_POST['name']."',`email`='".$_POST['email']."',`mobile`='".$_POST['mobile']."',`location`='".$_POST['location']."',`address`='".$_POST['address']."' WHERE `id`='".$_POST['user_id']."'";
	//echo $hosp_update_qry;
	$res_hhs_update=mysqli_query($link,$hhs_update_qry);
	if(isset($res_hhs_update))
	{
		?>
		<script>
						 alert("Details Updated Successfully.");
						window.location = 'adminviewupdatehhs.php';
					 </script>
		
		<?php
		
	}
	else
	{
		?>
		<script>
						alert("Something went wrong Please try agian later");
						window.location = 'adminviewupdatehhs.php';
					 </script>		
		<?php
	}
}


?>

</body>
</html>
<?php
}
else
{
echo "<script language='javascript'>window.location = 'adminlogin.php';</script>";exit();
}
?>