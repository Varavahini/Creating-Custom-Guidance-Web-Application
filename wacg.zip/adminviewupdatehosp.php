<?php 
include("db.php");
date_default_timezone_set('Asia/Kolkata'); 
$date=date('Y-m-d H:i:s');
if(isset($_SESSION['admin_id']))
{
	$login = $_SESSION['login'];
?>
<! DOC TYPE HTML>
<html>
<head>
<title>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="images/bg.jpg">
<form action="" method="POST">

<div class="form-group">
  <div class="container">
 <div class="container-fluid">
    <div class="row">
	  <div class="col-md-8">
         <h1 style="color:#2FA4C7;font-weight:bold;">CUSTOM GUIDENCE</h1>
      </div>
	  	 
    </div>
	</div>
<div class="container-fluid">
	  <div class="row">
	  <div class="col-md-12">
<nav class="navbar navbar-inverse">
 
    <ul class="nav navbar-nav">
      <li class="active"><a href="adminhome.php">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Hospital Services<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="adminhospreg.php">Register</a></li>
          <li><a href="adminviewupdatehosp.php">View/Update</a></li>
        </ul>
      </li>
	      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Household Services<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="adminhhsreg.php">Register</a></li>
          <li><a href="adminviewupdatehhs.php">View/Update</a></li>
        </ul>
      </li>

	   <li><a href="adminchangepassword.php">Change Password</a></li>
	   <li><a href="adminlogout.php">Logout</a></li>
    </ul>
</nav>
</div>
</div>
</div>
<h1 class="text-center">View & Update Medical Services</h1>
  <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-plus"></i></span>
      <input id="hospitalname" name="hospitalname" type="text" class="form-control"  placeholder="Enter Hospital Name" required>
    </div><br>
<center>
	<div class="form-group">
  <div class="container-fluid">
	<div class="row">
	 <div class="col-md-12">
	<div class="input-group">
      <button type="submit" class="btn btn-default" name="viewhosp" id="viewhosp"><i class="glyphicon glyphicon-search"></i>View</button>
	</div>
	</div>
	</div>
	</div>
	</div>
	</center>
</div>
</div>

</form>
<?php
if(isset($_POST['viewhosp']))
{
	$sql_get_data="SELECT * FROM `hospreg` WHERE `hospitalname`='".$_POST['hospitalname']."'";
		$get_hosp = mysqli_query($link,$sql_get_data) or die(mysqli_error($link));
						$count = mysqli_num_rows($get_hosp);
						if( $count != 0 ){
							while( $row = mysqli_fetch_array($get_hosp) ){
								$id = $row['id'];
							
$specialization= $row['specialization'];
$hospitalname= $row['hospitalname'];
$doctorname= $row['doctorname'];
$qualification= $row['qualification'];
$services= $row['services'];
$email= $row['email'];
$mobile= $row['mobile'];
$location= $row['location'];
$address= $row['address'];
							}
							?>
							<form action="" method="POST">
							<input type="hidden" name="user_id" value="<?php echo $id ; ?>">
							<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-th-list"></i></span>
   <select class="form-control" id="specialization" name="specialization">
   <option value="<?php echo $specialization; ?>"><?php echo $specialization; ?></option>
	<option value="">Specialization</option>
<option value="Accident and emergency medicine">Accident and emergency medicine</option>
<option value="Allergology">Allergology</option>
<option value="Anaesthetics">Anaesthetics</option>
<option value="Cardiology">Cardiology</option>
<option value="Child psychiatry">Child psychiatry</option>
<option value="Clinical biology">Clinical biology</option>
<option value="Clinical chemistry">Clinical chemistry</option>
<option value="Clinical microbiology">Clinical microbiology</option>
<option value="Clinical neurophysiology">Clinical neurophysiology</option>
<option value="Craniofacial surgery">Craniofacial surgery</option>
<option value="Dermatology">Dermatology</option>
<option value="Endocrinology">Endocrinology</option>
<option value="Family and General Medicine">Family and General Medicine</option>
<option value="Gastroenterologic surgery">Gastroenterologic surgery</option>
<option value="Gastroenterology">Gastroenterology</option>
<option value="General Practice">General Practice</option>
<option value="General surgery">General surgery</option>
<option value="Geriatrics">Geriatrics</option>
<option value="Hematology">Hematology</option>
<option value="Immunology">Immunology</option>
<option value="Infectious diseases">Infectious diseases</option>
<option value="Internal medicine">Internal medicine</option>
<option value="Laboratory medicine">Laboratory medicine</option>
<option value="Nephrology">Nephrology</option>
<option value="Neuropsychiatry">Neuropsychiatry</option>
<option value="Neurology">Neurology</option>
<option value="Neurosurgery">Neurosurgery</option>
<option value="Nuclear medicine">Nuclear medicine</option>
<option value="Obstetrics and gynaecology">Obstetrics and gynaecology</option>
<option value="Occupational medicine">Occupational medicine</option>
<option value="Oncology">Oncology</option>
<option value="Ophthalmology">Ophthalmology</option>
<option value="Oral and maxillofacial surgery">Oral and maxillofacial surgery</option>
<option value="Orthopaedics">Orthopaedics</option>
<option value="Otorhinolaryngology">Otorhinolaryngology</option>
<option value="Paediatric surgery">Paediatric surgery</option>
<option value="Paediatrics">Paediatrics</option>
<option value="Pathology">Pathology</option>
<option value="Pharmacology">Pharmacology</option>
<option value="Physical medicine and rehabilitation">Physical medicine and rehabilitation</option>
<option value="Plastic surgery">Plastic surgery</option>
<option value="Podiatric surgery">Podiatric surgery</option>
<option value="Preventive medicine">Preventive medicine</option>
<option value="Psychiatry">Psychiatry</option>
<option value="Public health">Public health</option>
<option value="Radiation Oncology">Radiation Oncology</option>
<option value="Radiology">Radiology</option>
<option value="Respiratory medicine">Respiratory medicine</option>
<option value="Rheumatology">Rheumatology</option>
<option value="Stomatology">Stomatology</option>
<option value="Thoracic surgery">Thoracic surgery</option>
<option value="Tropical medicine">Tropical medicine</option>
<option value="Urology">Urology</option>
<option value="Vascular surgery">Vascular surgery</option>
<option value="Venereology">Venereology</option>
	</select>
    </div>
	</div>
	</div>
	</div>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input id="name" type="text" class="form-control" name="hospitalname" placeholder="Enter Your Hospital Name" value="<?php echo $hospitalname;; ?>" required>
    </div>
	</div>
	</div>
	</div>
<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input id="name" type="text" class="form-control" name="doctorname" placeholder="Enter Your Doctor Name" value="<?php echo $doctorname; ?>"required>
    </div>
	</div>
	</div>
	</div>
<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
      <input id="qualification" type="text" class="form-control" name="qualification" placeholder="Enter Qualification" value="<?php echo $qualification; ?>"required>
    </div>
	</div>
	</div>
	</div>
<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
      <input id="email" type="email" class="form-control" name="email" placeholder="Enter Your Email" value="<?php echo $email; ?>" required>
    </div>
	</div>
	</div>
	</div>
	<br>
		<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
      <input id="mobile" type="text" class="form-control" name="mobile" placeholder="Enter Your Mobile Number" required value="<?php echo $mobile; ?>" pattern="^[6789]\d{9}$">
    </div>
	</div>
	</div>
	</div>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
     <select class="form-control" id="location" name="location">
	  <option value="<?php echo $location; ?>"><?php echo $location;?></option>
	<option>Location</option>
	<option value="Bhimavaram">Bhimavaram</option>
	<option value="Tanuku">Tanuku</option>
	<option value="Rajahmundry">Rajahmundry</option>
	
	</select>
    </div>
	</div>
	</div>
	</div>
	<br>
<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-list-alt"></i></span>
     <textarea class="form-control" placeholder="Address" name="address"><?php echo $address; ?></textarea> 
    </div>
</div>
	</div>
	</div>
	<br>
<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-list-alt"></i></span>
     <textarea class="form-control" placeholder="Services" name="services"><?php echo $services; ?></textarea> 
    </div>
</div>
	</div>
	</div>
	<br>
	<!--<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="password" type="password" class="form-control" name="password" placeholder="Password" required value="">
    </div>
</div>
	</div>
	</div>-->
	<div><br>
	     <center><button type="submit" class="btn btn-default" name="update_details"><i class="glyphicon glyphicon-ok"></i>Update</button></center>
    </div><br>
	</form>
							<?php
						}
						else
						{
							echo "<div style='text-align:center;'>Sorry No Records Found</div>";
						}
}
if(isset($_POST['update_details']))
{
	$hosp_update_qry="UPDATE `hospreg` SET `specialization`='".$_POST['specialization']."',`hospitalname`='".$_POST['hospitalname']."',`doctorname`='".$_POST['doctorname']."',`qualification`='".$_POST['qualification']."',`email`='".$_POST['email']."',`mobile`='".$_POST['mobile']."',`location`='".$_POST['location']."',`address`='".$_POST['address']."',`services`='".$_POST['services']."' WHERE `id`='".$_POST['user_id']."'";
	//echo $hosp_update_qry;
	$res_hosp_update=mysqli_query($link,$hosp_update_qry);
	if(isset($res_hosp_update))
	{
		?>
		<script>
						 alert("Details Updated Successfully.");
						window.location = 'adminviewupdatehosp.php';
					 </script>
		
		<?php
		
	}
	else
	{
		?>
		<script>
						alert("Something went wrong Please try agian later");
						window.location = 'adminviewupdatehosp.php';
					 </script>		
		<?php
	}
}


?>

</body>
</html>
<?php
}
else
{
echo "<script language='javascript'>window.location = 'adminlogin.php';</script>";exit();
}
?>