<?php
error_reporting(0);
session_start();
include('db.php');
if(isset($_SESSION['hosp_id']))
{
	$login = $_SESSION['login'];
if(isset($_POST['submit']))
	{
		
		$update_qry="UPDATE `queries` SET `response`='".$_POST['answer']."',`answeredby`='".$_POST['hosp_id']."'  WHERE `id`='".$_REQUEST['id']."'";
		//echo $update_qry;
		if (mysqli_query($link, $update_qry)) {
		echo "<script language='javascript'>alert('Answer Uploaded Successfully');
		window.location = 'hospviewreq.php';</script>";
		
	} else {
		echo "<script language='javascript'>alert('Something went wrong please try again later');
		window.location = 'hospviewreq.php';</script>";
		
	}
	}

?>

<! DOC TYPE HTML>
<html>
<head>
<title>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="images/bg.jpg">
<form action="" method="POST">

<div class="form-group">
  <div class="container">
 <div class="container-fluid">
    <div class="row">
	  <div class="col-md-8">
         <h1 style="color:#2FA4C7;font-weight:bold;">CUSTOM GUIDENCE</h1>
      </div>
	  	 
    </div>
	</div>
<div class="container-fluid">
	  <div class="row">
	  <div class="col-md-12">
<nav class="navbar navbar-inverse">
  <ul class="nav navbar-nav">
      <li class="active"><a href="hospitalhome.php">Home</a></li>
    <li><a href="hospviewreq.php">View Requests</a></li>
	<li><a href="hospchangepassword.php">Change Password</a></li>
	   <li><a href="hosplogout.php">Logout</a></li>
    </ul>
</nav>
</div>
</div>
</div>
<h1 class="text-center">ANSWERING QUERY</h1>
			<?php
					if(isset($_REQUEST['id']))
					{
						$get_user_details="SELECT * FROM `queries` WHERE `id`='".$_REQUEST['id']."'";
						$res_user_details=mysqli_query($link,$get_user_details);
						$response=mysqli_fetch_Assoc($res_user_details);
						$question=$response['query'];
						$askedby=$response['askedby'];
						echo '<form method="post">
						<div class="table-responsive">
 <table class="table">
						
						<tr>
					 <td align="right" style="color:#00853B;" width="420px">
					 Question:</td>
					 <td>
					 '.$question.'
					 </td>
					</tr>
						<tr>
						<tr>
					 <td align="right" style="color:#00853B;" width="420px">
					 Asked By:</td>
					 <td>
					 '.$askedby.'
					 </td>
					</tr>
						<tr>
					 <td align="right" style="color:#00853B;" width="420px">
					 Answer</td>
					 <td>
					 <textarea name="answer" placeholder="Answer"></textarea>
					 </td>
					</tr>
					<tr>
					 <td align="center" colspan="2">
					 <input class="btn" type="submit" name="submit" value="Submit">
					 </td>
					 </tr>';
					 
					 ?>
			 <input type="hidden" name="question" value="<?php echo $_REQUEST['id'];?>">
				
				<input type="hidden" name="hosp_id" value="<?php echo $login;?>">
					 <?php
					 
						echo "</table></div></form>";
					}
					
					?>
		
				
		
</form>
</body>
</html>
<?php
}
else
{
echo "<script language='javascript'>window.location = 'index.php';</script>";exit();
}
?>
