<! DOC TYPE HTML>
<html>
<head>
<title>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="images/bg.jpg">
<form action="">

<div class="form-group">
  <div class="container">
 <div class="container-fluid">
    <div class="row">
	  <div class="col-md-8">
         <h1 style="color:#2FA4C7;font-weight:bold;">CUSTOM GUIDENCE</h1>
      </div>
	  
	  <div class="form-group">
	   <div class="col-md-4 text-center">
	   <br>
        <a href="login.php" class="btn btn-info">Login</a>
		<a href="register.php" class="btn btn-info">Register</a>
		
		</div>
      </div>
    </div>
	</div>

<p class="text-justify" style="color:#900C3F;font-size:20px;">Web based applications for system guidance framework that enables the customers to make use of different sectors.This project puts together two sectors  i.e , hospital &pharmacy sector, house hold sector.In order to clarify their doubts or queries there is a spontaneous response  through online chat.This project is developed by keeping the view of problems faced by people by providing a user friendly application.
</p>
  <div class="container">
 <div class="row">

  <div class="col-md-6">
   <h2 class="text-center" style="color:#2FA4C7;">Medical Services</h2>
    <div class="thumbnail">
 
         
      
        <img src="images/medical.png" alt="Medical">
        
           <center><a href="medicalserach.php" class="btn btn-info"> Click Here</a></center>
        
      
    </div>
  </div>
  <div class="col-md-6">
  <h2 class="text-center" style="color:#2FA4C7;">Household Services</h2>
    <div class="thumbnail">
   
        

        <img src="images/household.png" alt="Households">
        <center><a href="userhhservices.php" class="btn btn-info"> Click Here</a></center>
        
     
    </div>
  </div>
  </div>
  </div>

</div>
</div>

</form>
</body>
</html>