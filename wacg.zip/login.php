<?php
include('db.php');

if(isset($_POST['login']))
{
$login_check = mysqli_query($link, "SELECT * from `user_login` where userid='".$_POST['email']."'  and password='".$_POST['pwd']."'") or die(mysqli_error($link));
	$count = mysqli_num_rows($login_check);
	$check = mysqli_fetch_assoc($login_check); 
		if($count==1)
			{
				$_SESSION['IsValid'] 	= true;
				$_SESSION['login']=$check['userid'];
			
				/*if($check['role']=='household')
				{
				$_SESSION['hhs_id'] = $check['id'];
				echo "<script language='javascript'>alert('login success');
				window.location = 'householdhome.php';</script>";
				}*/
				if($check['role']=='hospital')
				{
				$_SESSION['hosp_id'] = $check['id'];
				echo "<script language='javascript'>alert('login success');
				window.location = 'hospitalhome.php';</script>";
				}
				if($check['role']=='user')
				{
				$_SESSION['user_id'] = $check['id'];
				echo "<script language='javascript'>alert('login success');
				window.location = 'userhome.php';</script>";
				}
			
	
			}
		else
			{

                          echo "<script language = 'javascript'>alert('Login Successfully');window.location = 'login.php';</script>";
			}
			
		
			
				}
		


?>
<! DOC TYPE HTML>
<html>
<head>
<title>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="images/bg.jpg">
<form action="" method="POST">

<div class="form-group">
  <div class="container">
 <div class="container-fluid">
    <div class="row">
	  <div class="col-md-8">
        <h1 style="color:#2FA4C7;font-weight:bold;">CUSTOM GUIDENCE</h1>
      </div>
	  <div class="form-group">
	   <div class="col-md-4 text-center">
	   <br>
      <a href="login.php" class="btn btn-info">Login</a>
		<a href="register.php" class="btn btn-info">Register</a>
		</div>
      </div>
    </div>
	</div>

<h1 class="text-center">Login</h1>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
      <input id="email" type="text" class="form-control" name="email" placeholder="Enter Your Email" required>
    </div>
	</div>
	</div>
	</div>
	<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="password" type="password" class="form-control" name="pwd" placeholder="Password" required>
    </div>
</div>
	</div>
	</div>
	<br>
	<center>
	
  <div class="container">
	<div class="row">
	 <div class="col-md-12">
	<div class="input-group">
     <button type="submit" class="btn btn-default" name="login"><i class="glyphicon glyphicon-upload"></i>Login</button>
	</div>
	</div>
	</div>
	</div>
	</center>
	</div>
  </form>
	</body>
	</html>