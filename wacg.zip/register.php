<?php 
include("db.php");
date_default_timezone_set('Asia/Kolkata'); 

	if(isset($_POST['register']))
	{	
$hhd_check = mysqli_query($link, "SELECT * from `userreg` where mobile='".$_POST['mobile']."'") or die(mysqli_error($link));
	$count = mysqli_num_rows($hhd_check);
	$check = mysqli_fetch_assoc($hhd_check); 
		if($count==0)
			{


		$insert_sql="INSERT INTO `userreg`(`name`, `email`, `mobile`, `location`,`password`) VALUES ('".$_POST['name']."','".$_POST['email']."','".$_POST['mobile']."','".$_POST['location']."','".$_POST['password']."')";
		
					
		$result=mysqli_query($link,$insert_sql);
		 $id=mysqli_insert_id($link); 
		$insert_userloginsql="INSERT INTO `user_login`(`userid`, `password`, `role`) VALUES('".$_POST['email']."','".$_POST['password']."','user')";		
			
		$userlogin_result=mysqli_query($link,$insert_userloginsql);
  
       
        
	
		if($result||$userlogin_result)
		{
echo "<script>alert('User Registration Successfully');window.location = 'login.php';</script>";
		}
	
		
	}
		else
		{
	echo "<script language='javascript'>alert('User is Already Registered');window.location = 'register.php';</script>";
			
		}
		
	}

?>

<! DOC TYPE HTML>
<html>
<head>
<title>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="images/bg.jpg">
<form action="" method="POST">

<div class="form-group">
  <div class="container">
 <div class="container-fluid">
    <div class="row">
	  <div class="col-md-8">
         <h1 style="color:#2FA4C7;font-weight:bold;">CUSTOM GUIDENCE</h1>
      </div>
	  <div class="form-group">
	   <div class="col-md-4 text-center">
	   <br>
<a href="login.php" class="btn btn-info">Login</a>
		<a href="register.php" class="btn btn-info">Register</a>
		</div>
      </div>
    </div>
	</div>

<h1 class="text-center">New User Registration</h1>
<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input id="name" type="text" class="form-control" name="name" placeholder="Enter Your Name" required>
    </div>
	</div>
	</div>
	</div>
<br>
	<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
      <input id="email" type="email" class="form-control" name="email" placeholder="Enter Your Email" required>
    </div>
	</div>
	</div>
	</div>
	<br>
		<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
      <input id="mobile" type="text" class="form-control" name="mobile" placeholder="Enter Your Mobile Number" required pattern="^[6789]\d{9}$">
    </div>
	</div>
	</div>
	</div>
	<br>
<div class="container">
	<div class="row">
	<div class="col-sm-12">
	      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
     <select class="form-control" id="location" name="location">
	<option>Location</option>
	<option value="Bhimavaram">Bhimavaram</option>
	<option value="Tanuku">Tanuku</option>
	<option value="Rajahmundry">Rajahmundry</option>
	
	</select>
    </div>
	</div>
	</div>
	</div>
	<br>

	<div class="container">
	<div class="row">
	<div class="col-sm-12">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
    </div>
</div>
	</div>
	</div>
	<br>
	<center>
	
  <div class="container">
	<div class="row">
	 <div class="col-md-12">
	<div class="input-group">
     <button type="submit" class="btn btn-default" name="register"><i class="glyphicon glyphicon-upload"></i>Register</button>
	</div>
	</div>
	</div>
	</div>
	</center>
	</div>
  </form>
	</body>
	</html>