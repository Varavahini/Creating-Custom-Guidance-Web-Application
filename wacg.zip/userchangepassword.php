<?php 
include("db.php");
if(isset($_SESSION['user_id']))
{
	$login = $_SESSION['login'];
if(isset($_POST['change_pwd']))
	{
			//echo "<script language='javascript'>alert('testing');</script>";
		$sql_get_user = "SELECT * from `user_login` where userid='".$_POST['user_id']."' and password='".$_POST['oldpassword']."'";
		//echo $sql_get_user;
		$login_check = mysqli_query($link, $sql_get_user) or die(mysqli_error($link));
		$count = mysqli_num_rows($login_check);

		if($count==1)
			{
			$pwd_update  = mysqli_query($link, "UPDATE `user_login` SET password='".$_POST['newpassword']."' where userid='".$_SESSION['login']."' and password='".$_POST['oldpassword']."'") or die(mysqli_error($link));
			$login_check = mysqli_query($link, "SELECT * from `user_login` where userid='".$_SESSION['login']."' and password='".$_POST['newpassword']."'") or die(mysqli_error($link));
			$count = mysqli_num_rows($login_check);
			if($count==1)		
				{
					session_destroy();
					?>
					<script>
						 alert("Password Changed Successfully.");
						window.location = 'index.php';
					 </script>
					<?php
				}
				else
				{
					
					?>
					<script>
						alert("Something went wrong Please try agian later");
						window.location = 'userchangepassword.php';
					 </script>
					<?php
				}
			}
			else
			{
				    
					?>
					<script>
						alert("The details you entered are invalid Please try agian later");
						window.location = 'userchangepassword.php';
					 </script>
					<?php
			}
		
	}

?>
<! DOC TYPE HTML>
<html>
<head>
<title>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="images/bg.jpg">
<form action="" method="POST">

<div class="form-group">
  <div class="container">
 <div class="container-fluid">
    <div class="row">
	  <div class="col-md-8">
         <h1 style="color:#2FA4C7;font-weight:bold;">CUSTOM GUIDENCE</h1>
      </div>
	  	 
    </div>
	</div>
<div class="container-fluid">
	  <div class="row">
	  <div class="col-md-12">
<nav class="navbar navbar-inverse">
 
     <ul class="nav navbar-nav">
      <li><a href="userhome.php">Home</a></li>
    <li><a href="userhospservices.php">Hospital Services</a></li>
	<li><a href="userhspresponse.php">Hospital Response</a></li>
	<li><a href="userhhservices.php">Household Services</a></li>
		<li class="active"><a href="userchangepassword.php">Change Password</a></li>
	   <li><a href="userlogout.php">Logout</a></li>
    </ul>
</nav>
</div>
</div>
</div>
	<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12">
	<h1 class="text-center">CHANGE PASSWORD </h1>
	</div>
	</div>
<input type="hidden" id="user_id" name="user_id" value="<?php echo $login;?>">
	<br>
	  <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="oldpwd" name="oldpassword" type="password" class="form-control"  placeholder="Old Password" required>
    </div>
<br>	
	<div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input id="newpwd1" name="newpassword" type="password" class="form-control"  placeholder="New Password" required>
    </div>
	<br>
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input type="password" id="newpwd2" name="cpassword" class="form-control" placeholder="Confirm Password" required>
    </div>
	<br>
	<center>
	<div class="form-group">
  <div class="container-fluid">
	<div class="row">
	 <div class="col-md-12">
	<div class="input-group">
      <button type="submit" class="btn btn-default" name="change_pwd" id="change_pwd"><i class="glyphicon glyphicon-upload"></i>Submit</button>
	</div>
	</div>
	</div>
	</div>
	</div>
	</center>
	</div>
	</div>
	</div>
  </form>
  <script>
   $(document).ready(function(){
   //oldpwd,newpwd1,newpwd2,change_pwd,mobile_no,send_otp
   $('#change_pwd').click(function()
         {
             //name,gender,email,mobile,Rollnumber,pword
             var user_id = $('#user_id').val();
             var oldpwd    = $('#oldpwd').val();
             var newpwd1   = $('#newpwd1').val();
             var newpwd2   = $('#newpwd2').val();
            if(newpwd1 != newpwd2)                    
            {
               alert("Password mismatch...!");
               return false;
            }
            else
            {
               return true;
            }
            });
   });
   </script>
</body>
</html>
<?php
}
else
{
echo "<script language='javascript'>window.location = 'login.php';</script>";exit();
}
?>