<?php 
include("db.php");
date_default_timezone_set('Asia/Kolkata'); 
$date=date('Y-m-d H:i:s');
if(isset($_SESSION['user_id']))
{
	$login = $_SESSION['login'];
?>
<! DOC TYPE HTML>
<html>
<head>
<title>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="images/bg.jpg">
<form action="" method="POST">

<div class="form-group">
  <div class="container">
 <div class="container-fluid">
    <div class="row">
	  <div class="col-md-8">
         <h1 style="color:#2FA4C7;font-weight:bold;">CUSTOM GUIDANCE</h1>
      </div>
	  	 
    </div>
	</div>
<div class="container-fluid">
	  <div class="row">
	  <div class="col-md-12">
<nav class="navbar navbar-inverse">
 
    <ul class="nav navbar-nav">
      <li><a href="userhome.php">Home</a></li>
    <li><a href="userhospservices.php">Hospital Services</a></li>
	<li><a href="userhspresponse.php">Hospital Response</a></li>
	<li class="active"><a href="userhhservices.php">Household Services</a></li>
		<li><a href="userchangepassword.php">Change Password</a></li>
	   <li><a href="userlogout.php">Logout</a></li>
    </ul>
</nav>
</div>
</div>
</div>

<h1 class="text-center">Household Services</h1>
	<div class="form-group">
	
	<select class="form-control" id="location" name="location">
	<option>Location</option>
	<option value="Bhimavaram">Bhimavaram</option>
	<option value="Tanuku">Tanuku</option>
	<option value="Rajahmundry">Rajahmundry</option>
	
	</select>
	<br>
	<div class="form-group">
	
	<select class="form-control" id="category" name="category">
	<option value="">Category</option>
<option value="Cleaning">Cleaning</option>
<option value="TV and Electronics">TV and Electronics</option>
<option value="Assembly">Assembly</option>
<option value="General Handyman">General Handyman</option>
<option value="Plumbing">Plumbing</option>
<option value="Electrical">Electrical</option>
<option value="Painting">Painting</option>
<option value="Moving">Moving</option>
<option value="Smart Home">Smart Home</option>
<option value="Window Treatments">Window Treatments</option>
	</select>


	<br>
		<div>
	     <center><button type="submit" class="btn btn-default" name="hhssearch"><i class="glyphicon glyphicon-search"></i>Search</button></center>
    </div><br>
	<div class="table-responsive">
 <table class="table">
						<tr>
				<td>
				<?php
				if(isset($_POST['hhssearch']))
	{
				
	$get_qry="SELECT * FROM `householdreg` where `location`='".$_POST['location']."' AND `category`='".$_POST['category']."' ";
		$get_details = mysqli_query($link,$get_qry) or die(mysqli_error($link));
	$count = mysqli_num_rows($get_details); 
		if($count!=0)
			{

				echo "<center>
						
							<tr>
							
<th>Category</th>
<th>Name</th>
<th>Email</th>
<th>Mobile</th>
<th>Location</th>
<th>Address</th>


							</tr>
						
						";
				
				
				while($getrec = mysqli_fetch_array($get_details))
					{
						
	 $req_id=$getrec['id'];
						
$id= $getrec['id']; 
$category= $getrec['category'];
$name= $getrec['name'];
$email= $getrec['email'];
$mobile= $getrec['mobile'];
$location= $getrec['location'];
$address= $getrec['address'];



						
						
						
						echo "
							<tr>
<td>$category</td>
<td>$name</td>
<td>$email</td>
<td>$mobile</td>
<td>$location</td>
<td>$address</td>
";
									


echo "</td>
							
							</tr>
						
						";
					
					}
				
			}
	
			else
			{
				echo '<script>alert("No Records Found")</script>';
			}
	}
			?>
	
				</td>
				</tr>
				
			</table>
</div>
	</div>
	</div>
	</div>
  </form>
	</body>
	</html>
	<?php
}
else
{
echo "<script language='javascript'>window.location = 'login.php';</script>";exit();
}
?>