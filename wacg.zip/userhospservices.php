<?php 
include("db.php");
date_default_timezone_set('Asia/Kolkata'); 
$date=date('Y-m-d H:i:s');
if(isset($_SESSION['user_id']))
{
	$login = $_SESSION['login'];
?>
<! DOC TYPE HTML>
<html>
<head>
<title>
</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body background="images/bg.jpg">
<form action="" method="POST">

<div class="form-group">
  <div class="container">
 <div class="container-fluid">
    <div class="row">
	  <div class="col-md-8">
         <h1 style="color:#2FA4C7;font-weight:bold;">CUSTOM GUIDANCE</h1>
      </div>
	  	 
    </div>
	</div>
<div class="container-fluid">
	  <div class="row">
	  <div class="col-md-12">
<nav class="navbar navbar-inverse">
 
    <ul class="nav navbar-nav">
      <li><a href="userhome.php">Home</a></li>
    <li class="active"><a href="userhospservices.php">Hospital Services</a></li>
	<li><a href="userhspresponse.php">Hospital Response</a></li>
	<li><a href="userhhservices.php">Household Services</a></li>
		<li><a href="userchangepassword.php">Change Password</a></li>
	   <li><a href="userlogout.php">Logout</a></li>
    </ul>
</nav>
</div>
</div>
</div>

<h1 class="text-center">Medical Services</h1>
	<div class="form-group">
	
	<select class="form-control" id="location" name="location">
	<option>Location</option>
	<option value="Bhimavaram">Bhimavaram</option>
	<option value="Tanuku">Tanuku</option>
	<option value="Rajahmundry">Rajahmundry</option>
	
	</select>
	<br>
	<div class="form-group">
	
	<select class="form-control" id="specialization" name="specialization">
	<option value="">Specialization</option>
<option value="Accident and emergency medicine">Accident and emergency medicine</option>
<option value="Allergology">Allergology</option>
<option value="Anaesthetics">Anaesthetics</option>
<option value="Cardiology">Cardiology</option>
<option value="Child psychiatry">Child psychiatry</option>
<option value="Clinical biology">Clinical biology</option>
<option value="Clinical chemistry">Clinical chemistry</option>
<option value="Clinical microbiology">Clinical microbiology</option>
<option value="Clinical neurophysiology">Clinical neurophysiology</option>
<option value="Craniofacial surgery">Craniofacial surgery</option>
<option value="Dermatology">Dermatology</option>
<option value="Endocrinology">Endocrinology</option>
<option value="Family and General Medicine">Family and General Medicine</option>
<option value="Gastroenterologic surgery">Gastroenterologic surgery</option>
<option value="Gastroenterology">Gastroenterology</option>
<option value="General Practice">General Practice</option>
<option value="General surgery">General surgery</option>
<option value="Geriatrics">Geriatrics</option>
<option value="Hematology">Hematology</option>
<option value="Immunology">Immunology</option>
<option value="Infectious diseases">Infectious diseases</option>
<option value="Internal medicine">Internal medicine</option>
<option value="Laboratory medicine">Laboratory medicine</option>
<option value="Nephrology">Nephrology</option>
<option value="Neuropsychiatry">Neuropsychiatry</option>
<option value="Neurology">Neurology</option>
<option value="Neurosurgery">Neurosurgery</option>
<option value="Nuclear medicine">Nuclear medicine</option>
<option value="Obstetrics and gynaecology">Obstetrics and gynaecology</option>
<option value="Occupational medicine">Occupational medicine</option>
<option value="Oncology">Oncology</option>
<option value="Ophthalmology">Ophthalmology</option>
<option value="Oral and maxillofacial surgery">Oral and maxillofacial surgery</option>
<option value="Orthopaedics">Orthopaedics</option>
<option value="Otorhinolaryngology">Otorhinolaryngology</option>
<option value="Paediatric surgery">Paediatric surgery</option>
<option value="Paediatrics">Paediatrics</option>
<option value="Pathology">Pathology</option>
<option value="Pharmacology">Pharmacology</option>
<option value="Physical medicine and rehabilitation">Physical medicine and rehabilitation</option>
<option value="Plastic surgery">Plastic surgery</option>
<option value="Podiatric surgery">Podiatric surgery</option>
<option value="Preventive medicine">Preventive medicine</option>
<option value="Psychiatry">Psychiatry</option>
<option value="Public health">Public health</option>
<option value="Radiation Oncology">Radiation Oncology</option>
<option value="Radiology">Radiology</option>
<option value="Respiratory medicine">Respiratory medicine</option>
<option value="Rheumatology">Rheumatology</option>
<option value="Stomatology">Stomatology</option>
<option value="Thoracic surgery">Thoracic surgery</option>
<option value="Tropical medicine">Tropical medicine</option>
<option value="Urology">Urology</option>
<option value="Vascular surgery">Vascular surgery</option>
<option value="Venereology">Venereology</option>
	</select>


	<br>
		<div>
	     <center><button type="submit" class="btn btn-default" name="hospsearch"><i class="glyphicon glyphicon-search"></i>Search</button></center>
    </div><br>
	<div class="table-responsive">
 <table class="table">
						<tr>
				<td>
				<?php
				if(isset($_POST['hospsearch']))
	{
				
	$get_qry="SELECT * FROM `hospreg` where `location`='".$_POST['location']."' AND `specialization`='".$_POST['specialization']."' ";
		$get_details = mysqli_query($link,$get_qry) or die(mysqli_error($link));
	$count = mysqli_num_rows($get_details); 
		if($count!=0)
			{

				echo "<center>
						
							<tr>
							
<th>Specialization</th>
<th>Hospital Name</th>
<th>Doctor Name</th>
<th>Qualification</th>
<th>Services</th>
<th>Email</th>
<th>Mobile</th>
<th>Location</th>
<th>Address</th>
<th>Enter Query</th>


							</tr>
						
						";
				
				
				while($getrec = mysqli_fetch_array($get_details))
					{
						
	 $req_id=$getrec['id'];
						
$id= $getrec['id']; 
$specialization= $getrec['specialization'];
$hospitalname= $getrec['hospitalname'];
$doctorname= $getrec['doctorname'];
$qualification= $getrec['qualification'];
$services= $getrec['services'];
$email= $getrec['email'];
$mobile= $getrec['mobile'];
$location= $getrec['location'];
$address= $getrec['address'];



						
						
						
						echo "
							<tr>
<td>$specialization</td>
<td>$hospitalname</td>
<td>$doctorname</td>
<td>$qualification</td>
<td>$services</td>
<td>$email</td>
<td>$mobile</td>
<td>$location</td>
<td>$address</td>
<td><textarea name='query'></textarea></td>
<td>
<form>
<input type='hidden' name='ask_specialization' value='".$specialization."'/>
<input type='submit' value='Upload' name='askquery'></form></td>
";
									


echo "</td>
							
							</tr>
						
						";
					
					}
				
			}
	
			else
			{
				echo '<script>alert("No Records Found")</script>';
			}
	}
			?>
	
				</td>
				</tr>
				
			</table>
</div>
	</div>
	</div>
	</div>
  </form>
  <?php
			if(isset($_POST['askquery']))
				{
				
					
					$qry_insert="INSERT INTO `queries`(`specialization`,`query`,`askedby`) 
					VALUES ('".$_POST['ask_specialization']."','".$_POST['query']."','".$login."')";
					//echo $qry_insert;
					$result=mysqli_query($link,$qry_insert);
					if($result)
					{
						$get_user_details="SELECT query,response FROM `queries` WHERE `askedby`='".$login."'";
						$res_user_details=mysqli_query($link,$get_user_details);
						//echo $get_user_details;
						$response=mysqli_fetch_Array($res_user_details);
						$question=$response['query'];
						$answer=$response['response'];
						/*echo '<table align="center" width="990px">
						<tr>
					 <td align="right" style="color:#00853B;" width="420px">
					 Question:</td>
					 <td>
					 '.$question.'
					 </td>
					</tr>
						<tr>
					 <td align="right" style="color:#00853B;" width="420px">
					 Answer</td>
					 <td>
					  '.$answer.'
					 </td>
					</tr>
					';
						echo "</table>";*/
					
		echo "<script> alert('Query Uploaded successfully'); 
              </script>";
				
					}
					
					
				}
				?>
	</body>
	</html>
		<?php
}
else
{
echo "<script language='javascript'>window.location = 'login.php';</script>";exit();
}
?>